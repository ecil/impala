
# THIS FILE IS GENERATED FROM SETUP.PY
version = '1.2.0'
isrelease = 'True'