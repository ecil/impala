## kudu-python: Python interface to the Apache Kudu C++ Client API

Using this package requires that you install the Kudu C++ client libraries and
headers. See http://getkudu.io for more.

To install from PyPI, run

```
pip install kudu-python
```

Installation from source requires Cython.
