try:
    from jsonpointer import *
except ImportError :
    from _jsonpointer import *
