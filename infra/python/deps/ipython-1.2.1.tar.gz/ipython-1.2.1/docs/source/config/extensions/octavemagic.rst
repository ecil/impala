.. _extensions_octavemagic:

===========
octavemagic
===========

.. automodule:: IPython.extensions.octavemagic
