.. _extensions_cythonmagic:

===========
cythonmagic
===========

.. automodule:: IPython.extensions.cythonmagic
