We fixed an issue with switching between matplotlib inline and GUI backends,
but the fix requires matplotlib 1.1 or newer.  So from now on, we consider
matplotlib 1.1 to be the minimally supported version for IPython. Older
versions for the most part will work, but we make no guarantees about it.
